(function () {
  const POSTS_KEY = 'hocduongso_posts_v1';
  const COMMENTS_KEY = 'hocduongso_comments_v1';
  const REACTIONS_KEY = 'hocduongso_reactions_v1';

  function readJson(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (error) {
      console.warn('Không thể đọc localStorage:', key, error);
      return fallback;
    }
  }

  function writeJson(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function normalizePost(input, status) {
    const now = new Date().toISOString();
    return {
      id: input.id || `post_${Date.now()}_${Math.random().toString(16).slice(2, 8)}`,
      title: (input.title || '').trim(),
      category: (input.category || '').trim(),
      excerpt: (input.excerpt || '').trim(),
      content: (input.content || '').trim(),
      authorName: (input.authorName || '').trim() || 'Bạn đọc học đường',
      authorRole: (input.authorRole || '').trim(),
      tags: (input.tags || '').trim(),
      coverImage: input.coverImage || '',
      status: status || input.status || 'draft',
      createdAt: input.createdAt || now,
      updatedAt: now,
      reviewedAt: input.reviewedAt || '',
      reviewerNote: input.reviewerNote || ''
    };
  }

  function getPosts() {
    return readJson(POSTS_KEY, []);
  }

  function savePosts(posts) {
    writeJson(POSTS_KEY, posts);
    return posts;
  }

  function createPost(input, status) {
    const posts = getPosts();
    const post = normalizePost(input, status);
    posts.unshift(post);
    savePosts(posts);
    return post;
  }

  function updatePost(postId, updates) {
    const posts = getPosts();
    const index = posts.findIndex((item) => item.id === postId);
    if (index === -1) return null;
    posts[index] = normalizePost({ ...posts[index], ...updates }, updates.status || posts[index].status);
    savePosts(posts);
    return posts[index];
  }

  function getPublishedPosts() {
    return getPosts().filter((post) => post.status === 'published');
  }

  function getPostsByStatus(status) {
    return getPosts().filter((post) => post.status === status);
  }

  function getPostById(postId) {
    return getPosts().find((post) => post.id === postId) || null;
  }

  function seedPosts() {
    const posts = getPosts();
    if (posts.length > 0) return;
    const seed = [
      {
        id: 'seed_1',
        title: 'Podcast “An toàn số cho teen” của lớp 8C đạt 2.000 lượt nghe',
        category: 'Kỹ năng số',
        excerpt: 'Chuỗi podcast ngắn do học sinh tự sản xuất, chia sẻ mẹo an toàn mạng cho bạn cùng lứa.',
        content: 'Nhóm 8C đã lên kịch bản, thu âm, dựng hậu kỳ và phát hành đều đặn mỗi tuần. Nội dung tập trung vào cách bảo mật tài khoản, nhận diện tin giả và ứng xử văn minh trên mạng.',
        authorName: 'CLB Podcast 8C',
        authorRole: 'Học sinh lớp 8C',
        tags: 'podcast, an toàn số, kỹ năng số',
        coverImage: '',
        status: 'published',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        reviewedAt: new Date().toISOString(),
        reviewerNote: 'Bài viết đạt yêu cầu.'
      }
    ];
    savePosts(seed);
  }

  function getReactions() {
    return readJson(REACTIONS_KEY, {});
  }

  function setReaction(postId, reaction) {
    const reactions = getReactions();
    reactions[postId] = { ...(reactions[postId] || {}), ...reaction };
    writeJson(REACTIONS_KEY, reactions);
    return reactions[postId];
  }

  function getReaction(postId) {
    const reactions = getReactions();
    return reactions[postId] || { liked: false, saved: false };
  }

  function getComments(postId) {
    const comments = readJson(COMMENTS_KEY, {});
    return comments[postId] || [];
  }

  function addComment(postId, content, authorName) {
    const comments = readJson(COMMENTS_KEY, {});
    const list = comments[postId] || [];
    const item = {
      id: `cmt_${Date.now()}_${Math.random().toString(16).slice(2, 6)}`,
      authorName: authorName || 'Bạn đọc học đường',
      content: content.trim(),
      createdAt: new Date().toISOString()
    };
    comments[postId] = [item, ...list];
    writeJson(COMMENTS_KEY, comments);
    return item;
  }

  window.HocDuongStore = {
    getPosts,
    savePosts,
    createPost,
    updatePost,
    getPublishedPosts,
    getPostsByStatus,
    getPostById,
    seedPosts,
    getReaction,
    setReaction,
    getComments,
    addComment
  };
})();
