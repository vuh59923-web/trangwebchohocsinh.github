(function () {
  const store = window.HocDuongStore;
  const form = document.getElementById('submit-form');
  if (!form || !store) return;

  const params = new URLSearchParams(window.location.search);
  const editId = params.get('editId');
  const coverFile = document.getElementById('coverFile');
  const coverPreview = document.getElementById('cover-preview');
  const message = document.getElementById('submit-message');
  let coverImageData = '';

  const requiredRules = {
    title: 'Vui lòng nhập tiêu đề.',
    category: 'Vui lòng chọn chuyên mục.',
    excerpt: 'Vui lòng thêm mô tả ngắn.',
    content: 'Vui lòng nhập nội dung bài viết.',
    authorName: 'Vui lòng nhập tên tác giả.',
    authorRole: 'Vui lòng nhập lớp hoặc vai trò.',
    commitment: 'Bạn cần xác nhận cam kết nội dung.'
  };

  function setError(field, text) {
    const el = form.querySelector(`[data-error="${field}"]`);
    if (el) el.textContent = text || '';
  }

  function validate() {
    let valid = true;
    Object.entries(requiredRules).forEach(([field, msg]) => {
      const input = form.elements[field];
      const ok = field === 'commitment' ? input.checked : String(input.value).trim();
      if (!ok) {
        setError(field, msg);
        valid = false;
      } else {
        setError(field, '');
      }
    });
    return valid;
  }

  function fillForm(post) {
    form.elements.title.value = post.title || '';
    form.elements.category.value = post.category || '';
    form.elements.excerpt.value = post.excerpt || '';
    form.elements.content.value = post.content || '';
    form.elements.authorName.value = post.authorName || '';
    form.elements.authorRole.value = post.authorRole || '';
    form.elements.tags.value = post.tags || '';
    form.elements.commitment.checked = true;
    coverImageData = post.coverImage || '';
    if (coverImageData) {
      coverPreview.innerHTML = `<img src="${coverImageData}" alt="Ảnh bìa xem trước" />`;
    }
  }

  if (editId) {
    const post = store.getPostById(editId);
    if (post) {
      fillForm(post);
      message.textContent = 'Đang chỉnh sửa bài viết đã lưu.';
    }
  }

  coverFile.addEventListener('change', () => {
    const file = coverFile.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      coverImageData = String(reader.result || '');
      coverPreview.innerHTML = `<img src="${coverImageData}" alt="Ảnh bìa xem trước" />`;
    };
    reader.readAsDataURL(file);
  });

  function collectData() {
    return {
      title: form.elements.title.value,
      category: form.elements.category.value,
      excerpt: form.elements.excerpt.value,
      content: form.elements.content.value,
      authorName: form.elements.authorName.value,
      authorRole: form.elements.authorRole.value,
      tags: form.elements.tags.value,
      coverImage: coverImageData
    };
  }

  function submitByStatus(status) {
    if (!validate()) return;
    const payload = collectData();

    if (editId) {
      store.updatePost(editId, { ...payload, status });
    } else {
      store.createPost(payload, status);
      form.reset();
      coverImageData = '';
      coverPreview.textContent = 'Chưa có ảnh bìa';
    }

    message.textContent = status === 'draft'
      ? 'Đã lưu nháp thành công. Bạn có thể sửa tiếp trong “Bài của tôi”.'
      : 'Đã gửi phê duyệt. Admin sẽ phản hồi sớm!';
  }

  document.getElementById('save-draft').addEventListener('click', () => submitByStatus('draft'));
  document.getElementById('submit-pending').addEventListener('click', () => submitByStatus('pending'));
})();
