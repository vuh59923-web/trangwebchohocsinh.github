# Đề xuất nâng cấp giao diện “Học đường số” thành nền tảng mạng xã hội học đường

## 1. CONCEPT TỔNG THỂ

### Phong cách thiết kế mới
- **Social Learning Platform UI**: bố cục dạng feed trung tâm + panel ngữ cảnh (xu hướng, thử thách, bảng xếp hạng), thay cho bố cục báo điện tử nhiều khối tin tĩnh.
- **Card-first design**: mọi nội dung (bài viết, dự án, thử thách, xếp hạng) đều đóng gói theo card nhất quán để người dùng quét nhanh và tương tác nhanh.
- **Mobile-first interactive shell**: top app bar + tab feed + bottom navigation, cảm giác dùng như ứng dụng cộng đồng học đường.

### Từ khóa cảm xúc giao diện
- Trẻ trung, tích cực, năng động
- An toàn, thân thiện, rõ ràng
- Công nghệ nhưng gần gũi học đường
- Khuyến khích tham gia, chia sẻ, sáng tạo

### Tông màu chủ đạo
- **Primary**: Xanh dương công nghệ `#2563EB`
- **Secondary**: Xanh ngọc tích cực `#14B8A6`
- **Accent**: Cam năng lượng `#F59E0B`
- **Surface**: Trắng `#FFFFFF`, nền xám rất nhạt `#F8FAFC`
- **Text**: `#0F172A`, phụ `#475569`
- **Semantic**: thành công `#22C55E`, cảnh báo `#F59E0B`, an toàn số `#7C3AED`

### Vì sao layout mới giống mạng xã hội học đường hơn báo điện tử
- Có **feed theo ngữ cảnh** (Dành cho bạn/Đang theo dõi/Lớp em/Xu hướng) thay cho danh sách bài theo thời gian.
- Mỗi bài có **thanh tương tác chuẩn xã hội**: like, comment, lưu, chia sẻ.
- Có **story hoạt động nổi bật** theo lớp/CLB/sự kiện, tạo cảm giác “nhịp sống học đường theo thời gian thực”.
- Có **cá nhân hóa** và **gamification** (điểm, badge, bảng xếp hạng), tăng động lực quay lại hằng ngày.

---

## 2. SƠ ĐỒ THÔNG TIN TRANG CHỦ MỚI

1. **Top App Bar (sticky)**  
   Chứa logo, tìm kiếm, thông báo, tin nhắn, hồ sơ; là lớp điều hướng chính toàn trang.
2. **Story Học đường (horizontal scroll)**  
   Hiển thị hoạt động mới từ lớp/CLB/dự án/sự kiện; giúp vào nội dung nhanh bằng ảnh đại diện.
3. **Feed Tabs (sticky secondary)**  
   Chuyển giữa 4 luồng: Dành cho bạn, Đang theo dõi, Lớp em, Xu hướng.
4. **Main Feed (cột chính)**  
   Danh sách card bài viết có tương tác; lõi trải nghiệm “xem – tương tác – chia sẻ”.
5. **Right Panel Desktop / Under-feed Mobile**  
   - Khối Xu hướng học đường
   - Khối Thử thách sáng tạo số
   - Khối Gợi ý theo dõi
6. **Bảng xếp hạng Gamification**  
   Top học sinh/lớp/dự án, badge và điểm đổi mới số.
7. **Footer dạng platform**  
   Link nhanh, liên hệ, chính sách an toàn số, mạng xã hội chính thức.

---

## 3. THIẾT KẾ CHI TIẾT TỪNG SECTION

### A. Header / Top App Bar

**Desktop (>=1024px)**
- Trái: logo “Học đường số” (icon + wordmark), click về feed mặc định.
- Giữa: ô tìm kiếm rộng 420–520px, placeholder: “Tìm chủ đề, lớp, dự án, bài viết…”.
- Phải: icon chuông (thông báo), icon chat (tin nhắn lớp), icon bookmark nhanh, avatar hồ sơ.
- Bên dưới app bar: tab feed dạng pill:
  - Dành cho bạn
  - Đang theo dõi
  - Lớp em
  - Xu hướng
- Sticky top, shadow nhẹ `0 2px 12px rgba(15,23,42,.06)`.

**Mobile (<768px)**
- Hàng 1: logo trái, phải là 3 icon: tìm kiếm, thông báo, hồ sơ.
- Hàng 2: tab feed cuộn ngang (`overflow-x:auto; white-space:nowrap;`).
- Dùng bottom nav thay cho hiển thị đầy đủ menu.

### B. Story / Hoạt động nổi bật

- Dạng **story tròn** (avatar 56–64px) + nhãn dưới (tối đa 2 dòng).
- Mỗi story đại diện cho:
  - Lớp (VD: 8A1)
  - CLB (CLB Robotics)
  - Dự án (Vườn thủy canh IoT)
  - Sự kiện (Ngày hội STEM)
- Trạng thái:
  - **Mới**: viền gradient xanh-cam, có chấm “NEW”.
  - **Đã xem**: viền xám nhạt.
- Mobile cuộn ngang, có hiệu ứng snap nhẹ (`scroll-snap-type:x mandatory`).

### C. Feed chính

**Card chuẩn (mobile-first)**
- Nền trắng, bo góc `16px`, padding `14–16px`, margin-bottom `12–16px`.
- Header card:
  - avatar 40px (người đăng) hoặc icon lớp/trường
  - tên + vai trò (HS/GV/CLB)
  - timestamp (VD: “2 giờ trước”)
  - tag chuyên mục dạng chip (`#KỹNăngSố`, `#DựÁnSTEM`)
- Body card:
  - tiêu đề (16–18px semibold)
  - mô tả ngắn 2–3 dòng
  - media: ảnh 16:9 hoặc video thumbnail có icon play
- Footer tương tác:
  - Like, Comment, Lưu, Chia sẻ (icon + số)
  - Nút cao tối thiểu 40px, vùng bấm >= 44x44

**Loại card**
1. Chia sẻ học tập: có block “mẹo nhanh”, tài liệu đính kèm.
2. Dự án số: có badge “Dự án”, tiến độ %, CTA “Xem chi tiết”.
3. Review ứng dụng: có thang sao + ưu/nhược điểm ngắn.
4. Cảnh báo kỹ năng số: nền nhấn tím nhạt, icon khiên an toàn.
5. Thử thách học đường: có countdown + nút “Tham gia”.

**Ưu tiên thị giác**
1) Avatar + tên nguồn đăng (độ tin cậy)  
2) Tiêu đề  
3) Media  
4) CTA tương tác  
5) Metadata phụ

### D. Khối “Xu hướng học đường”

**Desktop**: panel phải, sticky theo viewport (trừ footer).  
**Mobile**: chuyển xuống dưới feed chính.

Nội dung gồm 3 cụm:
- **Hashtag nóng**: `#HocToanBangAI`, `#Robot8A1`, `#AnToanMang`.
- **Chủ đề hot tuần** (mini list top 5).
- **Bài nổi bật tuần**: 1 card compact có thumbnail + tiêu đề + số tương tác.

### E. Khối “Dành cho bạn”

Cơ chế gợi ý cá nhân hóa (rule-based trước, ML sau):
- Theo lớp (6/7/8/9)
- Theo môn quan tâm (Toán/Lý/Văn/Anh/Tin)
- Theo hành vi: bài đã like/save/comment
- Theo chủ đề đang follow

UI thể hiện:
- Tiêu đề “Dành cho bạn” + nhãn “Gợi ý hôm nay”.
- 3–5 card compact với lý do gợi ý: “Vì bạn theo dõi #STEM”.

### F. Khối “Thử thách sáng tạo số”

- Hero card nhỏ ở panel phải hoặc chèn sau card feed thứ 3.
- Nội dung:
  - Tên challenge tuần (VD: “Thiết kế poster An toàn số 2026”)
  - Countdown (còn 03 ngày)
  - Badge phần thưởng (50 điểm đổi mới + huy hiệu)
  - Nút chính: **Tham gia ngay**
  - Danh sách 3 bài tham gia nổi bật (thumbnail + lớp)

### G. Bảng xếp hạng / gamification

Tabs:
- Top học sinh sáng tạo
- Top lớp tích cực
- Top dự án tuần

Mỗi hàng gồm:
- thứ hạng #1/#2/#3 + icon huy hiệu
- tên người/lớp/dự án
- điểm đổi mới số
- cấp độ thành viên (Explorer / Innovator / Leader)

Có tooltip giải thích điểm để minh bạch, tránh cảm giác “thi đua tiêu cực”.

### H. Footer

Dạng gọn, nền đậm nhẹ.
- Cột 1: logo + mô tả ngắn nền tảng.
- Cột 2: liên kết nhanh (Feed, Dự án, Thử thách, Bảng xếp hạng).
- Cột 3: hỗ trợ & liên hệ.
- Cột 4: Chính sách an toàn học đường số, quyền riêng tư, hướng dẫn phụ huynh.
- Dòng cuối: bản quyền + social icons chính thức.

---

## 4. UX FLOW

1. **Lần đầu vào web**
- Thấy ngay app bar + story + tab “Dành cho bạn”.
- Feed hiển thị card đa dạng, có card onboarding “Bắt đầu theo dõi chủ đề”.

2. **Bắt đầu tương tác**
- Người dùng bấm like/comment ngay trên card (không cần rời feed).
- Lần đầu comment mở bottom-sheet nhẹ với guideline ứng xử học đường số.

3. **Luồng chuẩn**
- Đọc bài -> Like -> Mở comment -> Theo dõi tác giả/chủ đề -> quay lại feed giữ vị trí cũ.
- Dùng kỹ thuật lưu vị trí scroll + cache feed tab.

4. **Tránh rối thông tin**
- Mỗi khối có tiêu đề ngắn, icon rõ ngữ nghĩa.
- Giới hạn số card phụ trên viewport đầu.
- Dùng khoảng trắng lớn và phân cấp chữ tối đa 3 cấp.

5. **Ưu tiên trên mobile**
- Ưu tiên 3 hành động: Like, Comment, Save.
- Share để mức ưu tiên sau (icon cuối).
- CTA chính (Tham gia challenge) luôn đủ nổi bật.

---

## 5. THIẾT KẾ MOBILE-FIRST

- **Header mobile**: 56px, sticky top.
- **Điều hướng**: bottom navigation 4 mục: Trang chủ / Xu hướng / Thử thách / Hồ sơ.
- **Story**: 1 hàng ngang, avatar 56px, snap scroll.
- **Feed**: 1 cột, card full-width trừ lề 12px.
- **Panel xu hướng**: đẩy xuống dưới feed (accordion để gọn).
- **Nút tương tác**: icon + label, min-height 40px.
- **Typography**:
  - title card 16px
  - body 14px
  - meta 12px
- **Khoảng cách**:
  - section gap 16px
  - card padding 14px
  - line-height 1.4–1.6
- **Sticky**:
  - top app bar sticky
  - feed tab sticky dưới app bar
  - bottom nav sticky cuối màn hình

---

## 6. GỢI Ý TRIỂN KHAI FRONTEND

### Danh sách section
- `app-shell`
- `top-appbar`
- `story-strip`
- `feed-tabs`
- `home-layout`
- `feed-main`
- `side-panel`
- `leaderboard-block`
- `platform-footer`

### Class HTML gợi ý
- `.appbar`, `.appbar__logo`, `.appbar__search`, `.appbar__actions`
- `.story-strip`, `.story-item`, `.story-item--new`, `.story-item--seen`
- `.feed-tabs`, `.feed-tabs__btn`, `.is-active`
- `.post-card`, `.post-card__head`, `.post-card__media`, `.post-card__actions`
- `.trend-panel`, `.challenge-card`, `.recommend-list`
- `.leaderboard`, `.leaderboard__tabs`, `.rank-item`
- `.bottom-nav`

### Cấu trúc DOM mẫu
```html
<div class="app-shell">
  <header class="appbar">...</header>

  <main class="home-page">
    <section class="story-strip">...</section>
    <nav class="feed-tabs">...</nav>

    <div class="home-layout">
      <section class="feed-main">
        <article class="post-card post-card--project">...</article>
        <article class="post-card post-card--safety">...</article>
      </section>

      <aside class="side-panel">
        <section class="trend-panel">...</section>
        <section class="challenge-card">...</section>
        <section class="recommend-list">...</section>
      </aside>
    </div>

    <section class="leaderboard-block">...</section>
  </main>

  <footer class="platform-footer">...</footer>
  <nav class="bottom-nav">...</nav>
</div>
```

### Gợi ý CSS
- Dùng CSS variables cho màu/spacing/radius.
- Grid desktop: `grid-template-columns: minmax(0, 1fr) 320px; gap: 24px;`
- Mobile: side-panel xuống dưới bằng `order` hoặc stack block.
- Card:
  - `border-radius:16px;`
  - `box-shadow:0 4px 20px rgba(15,23,42,.06);`
  - hover desktop nâng nhẹ.
- Responsive breakpoints:
  - `sm: 576`
  - `md: 768`
  - `lg: 1024`
  - `xl: 1280`

### JS tính năng nên có
- Story slider (drag + snap + trạng thái seen).
- Feed tabs (load data theo tab, preserve scroll).
- Save bài (toggle state localStorage khi chưa đăng nhập).
- Like animation (micro-interaction 150–220ms).
- Filter theo chủ đề (chip filters + query params).

---

## 7. ĐỀ XUẤT CẢI TIẾN SÁNG TẠO ĐỂ TĂNG KHẢ NĂNG ĐẠT GIẢI

1. **Story học đường theo lớp**: mỗi lớp có “nhật ký số” trong 24h.
2. **Hồ sơ học sinh số**: tổng hợp dự án, huy hiệu, kỹ năng nổi bật.
3. **Huy hiệu công dân số**: đạt qua hành vi tốt (bình luận văn minh, chia sẻ nguồn chuẩn).
4. **Bản đồ dự án toàn trường**: xem dự án theo lớp/phòng học/khu vực.
5. **AI gợi ý bài đọc an toàn**: đề xuất theo môn và độ tuổi THCS.
6. **Góc lớp em**: kênh riêng cho thông báo + thành tích lớp.
7. **Thử thách theo tuần liên trường**: thi đua tích cực, có rubric chấm rõ ràng.

---

## ASCII WIREFRAME — DESKTOP

```text
┌──────────────────────────────────────────────────────────────────────────────┐
│ LOGO | Search............................ | 🔔 💬 🔖 👤                       │
├──────────────────────────────────────────────────────────────────────────────┤
│ [Dành cho bạn] [Đang theo dõi] [Lớp em] [Xu hướng]                           │
├──────────────────────────────────────────────────────────────────────────────┤
│ Story: (Lớp 8A1) (CLB STEM) (Sự kiện) (Dự án) (....scroll....)              │
├───────────────────────────────┬──────────────────────────────────────────────┤
│ FEED CHÍNH                    │ PANEL PHẢI                                  │
│ ┌───────────────────────────┐ │ ┌──────────────────────────────────────────┐ │
│ │ Avatar Tên  • 2h • #Tag   │ │ │ Xu hướng học đường                      │ │
│ │ Tiêu đề bài viết           │ │ │ #HocToanBangAI                          │ │
│ │ Mô tả ngắn...              │ │ │ #AnToanMang                             │ │
│ │ [ Ảnh / Video ]            │ │ └──────────────────────────────────────────┘ │
│ │ ❤️ 120  💬 34  🔖 20  ↗︎    │ │ ┌──────────────────────────────────────────┐ │
│ └───────────────────────────┘ │ │ Thử thách sáng tạo số + Countdown        │ │
│ ┌───────────────────────────┐ │ │ [Tham gia ngay]                          │ │
│ │ ... card tiếp theo ...    │ │ └──────────────────────────────────────────┘ │
│ └───────────────────────────┘ │ ┌──────────────────────────────────────────┐ │
│                               │ │ Dành cho bạn (gợi ý cá nhân hóa)         │ │
│                               │ └──────────────────────────────────────────┘ │
├───────────────────────────────┴──────────────────────────────────────────────┤
│ Bảng xếp hạng: [Top HS] [Top Lớp] [Top Dự án]                               │
├──────────────────────────────────────────────────────────────────────────────┤
│ Footer: Link nhanh | Liên hệ | Chính sách an toàn số                        │
└──────────────────────────────────────────────────────────────────────────────┘
```

## ASCII WIREFRAME — MOBILE

```text
┌──────────────────────────────┐
│ LOGO              🔍 🔔 👤   │  <- Sticky Header
├──────────────────────────────┤
│ [Dành cho bạn][Theo dõi][...]│  <- Tab cuộn ngang sticky
├──────────────────────────────┤
│ Story ○ ○ ○ ○ ○  ->          │  <- Scroll ngang
├──────────────────────────────┤
│ Card bài viết                │
│ Avatar Tên • #Tag            │
│ Tiêu đề                      │
│ Mô tả ngắn                   │
│ [Ảnh/Video]                  │
│ ❤️  💬  🔖  ↗︎               │
├──────────────────────────────┤
│ Card bài viết                │
├──────────────────────────────┤
│ Xu hướng học đường           │
├──────────────────────────────┤
│ Thử thách sáng tạo số        │
│ [Tham gia ngay]              │
├──────────────────────────────┤
│ Bảng xếp hạng rút gọn         │
├──────────────────────────────┤
│ Footer                        │
├──────────────────────────────┤
│ 🏠  #  🎯  👤                │ <- Bottom Nav Sticky
└──────────────────────────────┘
```

## Danh sách component cần code trước (ưu tiên)

### Ưu tiên P0 (bắt buộc để chạy trải nghiệm cốt lõi)
1. App Shell + Top App Bar (desktop/mobile)
2. Feed Tabs + chuyển tab
3. Post Card base + action bar (like/comment/save/share)
4. Story Strip horizontal
5. Layout responsive (feed + side panel + mobile stack)
6. Bottom Navigation mobile

### Ưu tiên P1 (tăng chất lượng trải nghiệm)
7. Trend Panel
8. Challenge Card + countdown
9. Recommend block “Dành cho bạn”
10. Leaderboard tabs

### Ưu tiên P2 (nâng cao, tạo khác biệt)
11. Like animation + optimistic UI
12. Save state localStorage
13. Filter chips theo chủ đề
14. Skeleton loading + empty states
15. Safety prompt khi comment lần đầu
