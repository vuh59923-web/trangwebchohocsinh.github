(function () {
  const store = window.HocDuongStore;
  if (store) {
    store.seedPosts();
  }

  const navToggle = document.querySelector('.nav-toggle');
  const mainNav = document.querySelector('.main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    document.addEventListener('click', (event) => {
      if (!mainNav.classList.contains('open')) return;
      const clickedInsideMenu = mainNav.contains(event.target) || navToggle.contains(event.target);
      if (!clickedInsideMenu) {
        mainNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });

    mainNav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  const revealItems = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.12 });

    revealItems.forEach((item) => revealObserver.observe(item));
  } else {
    revealItems.forEach((item) => item.classList.add('visible'));
  }

  const categoryCards = document.querySelectorAll('#categories .category-card');
  categoryCards.forEach((card) => {
    card.addEventListener('click', (event) => {
      categoryCards.forEach((item) => item.classList.remove('active'));
      card.classList.add('active');

      const targetLink = card.dataset.link || card.getAttribute('href');
      if (!targetLink) return;

      event.preventDefault();
      window.location.href = targetLink;
    });
  });

  function formatDate(iso) {
    return new Date(iso).toLocaleString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  function toArticleLink(postId) {
    return `article-template.html?postId=${encodeURIComponent(postId)}`;
  }

  const articleLibrary = [
    {
      id: 'featured-school-map',
      category: 'Dự án số học sinh',
      title: 'Nhóm lớp 9 tạo website “Sơ đồ trường thông minh” giúp học sinh mới tìm lớp trong 10 giây',
      author: 'CLB Truyền thông số',
      date: '07/04/2026',
      readTime: '4 phút',
      bannerText: '🛰️ Ảnh đầu bài: Mô phỏng giao diện dự án số học sinh',
      paragraphs: [
        'Dự án “Sơ đồ trường thông minh” do ba bạn học sinh lớp 9 thực hiện trong 6 tuần. Nhóm dùng bản đồ số kết hợp mã QR để học sinh mới tra cứu phòng học ngay trên điện thoại.',
        'Khi nhập tên lớp hoặc phòng chức năng, hệ thống gợi ý lộ trình ngắn nhất và hiển thị các điểm quan trọng như thư viện số, phòng STEM, phòng y tế.'
      ],
      sectionTitle: 'Vì sao dự án được yêu thích?',
      bullets: [
        'Thiết kế thân thiện với học sinh THCS, chữ rõ và màu dễ nhìn.',
        'Không cần cài app, chỉ quét mã QR là dùng được ngay.',
        'Có khu góp ý để cập nhật lỗi và đề xuất tính năng mới.'
      ],
      related: ['featured-ai-checklist', 'latest-time-management-apps', 'featured-fake-news']
    },
    {
      id: 'featured-ai-checklist',
      category: 'AI & Học tập thông minh',
      title: 'Checklist 5 bước dùng AI tóm tắt bài mà vẫn hiểu sâu kiến thức',
      author: 'Tổ công nghệ học tập',
      date: '07/04/2026',
      readTime: '5 phút',
      bannerText: '🤖 Ảnh đầu bài: Sơ đồ checklist dùng AI học đúng cách',
      paragraphs: [
        'Nhiều bạn dùng AI để tóm tắt bài nhưng dễ bị học vẹt. Checklist 5 bước giúp giữ vai trò chủ động của người học trong từng môn.',
        'Mỗi bước đều yêu cầu đối chiếu với SGK, ghi chú lại bằng ngôn ngữ của chính mình và tự kiểm tra bằng câu hỏi ngắn.'
      ],
      sectionTitle: 'Checklist 5 bước',
      bullets: [
        'Đặt mục tiêu rõ: tóm tắt phần nào, phục vụ bài nào.',
        'Yêu cầu AI trả lời theo ý chính + ví dụ thực tế.',
        'Đối chiếu ít nhất 2 nguồn học liệu chính thống.',
        'Viết lại bản tóm tắt bằng từ ngữ của bạn.',
        'Tự làm 3 câu hỏi kiểm tra trước khi nộp bài.'
      ],
      related: ['latest-ai-presentation', 'featured-fake-news', 'latest-green-digital']
    },
    {
      id: 'featured-fake-news',
      category: 'Kỹ năng số',
      title: 'Khi gặp tin giả trên mạng: học sinh nên kiểm tra nguồn như thế nào?',
      author: 'Nhóm An toàn số THCS',
      date: '06/04/2026',
      readTime: '4 phút',
      bannerText: '🧠 Ảnh đầu bài: Sơ đồ kiểm tra độ tin cậy thông tin',
      paragraphs: [
        'Tin giả thường đánh vào cảm xúc và tốc độ chia sẻ. Vì vậy, học sinh cần dừng lại trước khi bấm chia sẻ.',
        'Chỉ cần 60 giây kiểm tra nguồn, bạn đã có thể tránh lan truyền thông tin sai trong nhóm lớp.'
      ],
      sectionTitle: '3 câu hỏi cần tự kiểm tra',
      bullets: [
        'Nguồn này có tên rõ ràng và đáng tin không?',
        'Nội dung có dẫn chứng hoặc liên kết tới dữ liệu gốc không?',
        'Có báo/chuyên trang uy tín nào xác nhận cùng thông tin không?'
      ],
      related: ['latest-account-security', 'featured-ai-checklist', 'latest-history-animation']
    },
    {
      id: 'featured-flashcard-review',
      category: 'Review app học đường',
      title: 'Review nhanh app flashcard tiếng Anh: dễ tạo bộ thẻ, học theo nhóm',
      author: 'Ban biên tập Review app',
      date: '06/04/2026',
      readTime: '3 phút',
      bannerText: '📱 Ảnh đầu bài: Giao diện bộ thẻ tiếng Anh theo chủ đề',
      paragraphs: [
        'Ứng dụng flashcard được học sinh ưa chuộng vì tạo bộ thẻ nhanh, có chế độ ôn tập thông minh theo mức độ nhớ.',
        'Điểm cộng lớn là chức năng học nhóm: mỗi thành viên thêm ví dụ riêng, cả nhóm cùng ôn theo lịch chung.'
      ],
      sectionTitle: 'Điểm nổi bật tuần này',
      bullets: [
        'Tạo bộ thẻ từ file từ vựng chỉ trong vài phút.',
        'Theo dõi tiến độ nhớ từ theo từng ngày.',
        'Học theo nhóm lớp với cơ chế chia sẻ linh hoạt.'
      ],
      related: ['latest-time-management-apps', 'latest-ai-presentation', 'latest-green-digital']
    },
    {
      id: 'latest-green-digital',
      category: 'Teen thời công nghệ',
      title: 'Teen trường mình đang “sống xanh số” thế nào qua thử thách 7 ngày không lãng phí điện?',
      author: 'CLB Xanh số',
      date: '08/04/2026',
      readTime: '4 phút',
      bannerText: '📸 Ảnh đầu bài: Bảng theo dõi thử thách sống xanh số',
      paragraphs: [
        'Thử thách 7 ngày “không lãng phí điện” được triển khai ở 12 lớp với app chấm điểm tiết kiệm năng lượng.',
        'Các nhóm học sinh ghi lại thói quen bật/tắt thiết bị, so sánh mức tiêu thụ và đề xuất thay đổi ngay trong lớp.'
      ],
      sectionTitle: 'Kết quả đáng chú ý',
      bullets: [
        'Giảm 18% thời gian bật điều hòa ngoài khung giờ cần thiết.',
        '100% lớp tham gia cam kết tắt thiết bị trước khi rời phòng.',
        'Nhiều lớp chia sẻ checklist tiết kiệm điện để nhân rộng.'
      ],
      related: ['latest-air-sensor-lab', 'latest-account-security', 'featured-school-map']
    },
    {
      id: 'latest-ai-presentation',
      category: 'AI & Học tập thông minh',
      title: 'Làm bài thuyết trình cùng AI: cách đặt câu hỏi thông minh để không bị lệ thuộc',
      author: 'Giáo viên Tin học + Nhóm 8A',
      date: '08/04/2026',
      readTime: '5 phút',
      bannerText: '🤖 Ảnh đầu bài: Mẫu prompt hỗ trợ làm thuyết trình',
      paragraphs: [
        'Trong tiết thực hành, học sinh được hướng dẫn cách đặt prompt theo mục tiêu cụ thể thay vì yêu cầu AI làm toàn bộ bài.',
        'Nhờ đó, các bạn vẫn giữ được tiếng nói cá nhân và biết cách kiểm chứng thông tin trước khi đưa vào slide.'
      ],
      sectionTitle: 'Nguyên tắc đặt câu hỏi với AI',
      bullets: [
        'Nêu rõ lớp, môn, phạm vi nội dung cần hỗ trợ.',
        'Yêu cầu AI gợi ý dàn ý chứ không viết hộ toàn bộ.',
        'Luôn thêm bước kiểm chứng dữ liệu từ nguồn học liệu chính.'
      ],
      related: ['featured-ai-checklist', 'latest-history-animation', 'featured-fake-news']
    },
    {
      id: 'latest-air-sensor-lab',
      category: 'Lớp học sáng tạo số',
      title: 'Tiết Khoa học 8 biến thành “phòng lab mini” với cảm biến đo chất lượng không khí',
      author: 'Tổ Khoa học tự nhiên',
      date: '08/04/2026',
      readTime: '4 phút',
      bannerText: '🧪 Ảnh đầu bài: Mô hình cảm biến không khí trong lớp học',
      paragraphs: [
        'Học sinh lớp 8 tự lắp cảm biến mini để đo nồng độ bụi mịn và CO2 trong các khung giờ khác nhau.',
        'Từ dữ liệu thu được, cả lớp đề xuất kế hoạch mở cửa sổ, trồng cây và điều chỉnh quạt thông gió hợp lý hơn.'
      ],
      sectionTitle: 'Bài học rút ra từ dự án',
      bullets: [
        'Dữ liệu giúp học sinh hiểu rõ tác động của môi trường tới sức khỏe.',
        'Các nhóm luyện kỹ năng đọc biểu đồ và trình bày kết quả.',
        'Mô hình có thể nhân rộng cho nhiều phòng học khác.'
      ],
      related: ['latest-green-digital', 'featured-school-map', 'latest-history-animation']
    },
    {
      id: 'latest-time-management-apps',
      category: 'Review app học đường',
      title: '3 app quản lý thời gian học được học sinh lớp 7 bình chọn cao nhất tuần này',
      author: 'Nhóm review lớp 7',
      date: '08/04/2026',
      readTime: '3 phút',
      bannerText: '📲 Ảnh đầu bài: Bảng so sánh 3 app quản lý thời gian',
      paragraphs: [
        'Cuộc bình chọn tuần này tập trung vào các app dễ dùng, nhắc lịch đều và phù hợp thời khóa biểu học sinh THCS.',
        'Mỗi app được chấm theo tiêu chí: giao diện, mức độ nhắc việc và khả năng đồng bộ giữa điện thoại - máy tính bảng.'
      ],
      sectionTitle: 'Top 3 app được bình chọn',
      bullets: [
        'App A: giao diện đơn giản, nhắc lịch học đúng giờ.',
        'App B: có chế độ Pomodoro và thống kê thời gian.',
        'App C: hỗ trợ làm việc nhóm, chia sẻ lịch theo tổ.'
      ],
      related: ['featured-flashcard-review', 'latest-ai-presentation', 'latest-account-security']
    },
    {
      id: 'latest-account-security',
      category: 'Kỹ năng số',
      title: 'Bộ quy tắc 4 lớp bảo vệ tài khoản học sinh khi học và trao đổi online',
      author: 'Ban an toàn thông tin học đường',
      date: '08/04/2026',
      readTime: '4 phút',
      bannerText: '🔐 Ảnh đầu bài: Mô hình 4 lớp bảo vệ tài khoản học sinh',
      paragraphs: [
        'Tài khoản học tập đang là “chìa khóa” của nhiều hoạt động trường lớp nên cần được bảo vệ theo nhiều lớp.',
        'Bộ quy tắc 4 lớp giúp học sinh xử lý từ khâu tạo mật khẩu đến phản ứng khi phát hiện đăng nhập bất thường.'
      ],
      sectionTitle: '4 lớp bảo vệ cần có',
      bullets: [
        'Mật khẩu mạnh, khác nhau cho từng nền tảng.',
        'Bật xác thực 2 bước cho tài khoản quan trọng.',
        'Không chia sẻ mã OTP, kể cả với người quen.',
        'Kiểm tra thiết bị đăng nhập và đăng xuất định kỳ.'
      ],
      related: ['featured-fake-news', 'latest-time-management-apps', 'latest-green-digital']
    },
    {
      id: 'latest-history-animation',
      category: 'Dự án số học sinh',
      title: 'Từ ý tưởng đến video animation: đội media 8B kể chuyện lịch sử bằng công nghệ số',
      author: 'Đội Media 8B',
      date: '08/04/2026',
      readTime: '5 phút',
      bannerText: '🚀 Ảnh đầu bài: Hậu trường dựng video animation lịch sử',
      paragraphs: [
        'Đội media 8B biến bài học lịch sử thành video animation ngắn, kết hợp hình minh họa, lồng tiếng và nhạc nền tự chọn.',
        'Dự án giúp các bạn nhớ mốc sự kiện tốt hơn, đồng thời rèn kỹ năng viết kịch bản và dựng hậu kỳ bằng công cụ số.'
      ],
      sectionTitle: 'Quy trình làm video của đội 8B',
      bullets: [
        'Chọn chủ đề lịch sử và chia nhóm theo vai trò.',
        'Viết storyboard, dựng cảnh và ghi âm thuyết minh.',
        'Nhận góp ý từ giáo viên trước khi xuất bản bản cuối.'
      ],
      related: ['featured-school-map', 'latest-ai-presentation', 'latest-air-sensor-lab']
    }
  ];

  const articleById = articleLibrary.reduce((accumulator, article) => {
    accumulator[article.id] = article;
    return accumulator;
  }, {});

  function renderCommunityPosts() {
    const list = document.querySelector('#community-posts-list');
    if (!list || !store) return;

    const published = store.getPublishedPosts();
    if (published.length === 0) {
      list.innerHTML = '<p class="empty-state card">Chưa có bài cộng đồng nào được xuất bản.</p>';
      return;
    }

    list.innerHTML = published.map((post) => `
      <article class="post-card card" data-post-id="${post.id}">
        <div class="thumb">📝</div>
        <p class="chip">${post.category}</p>
        <h3><a href="${toArticleLink(post.id)}">${post.title}</a></h3>
        <p>${post.excerpt}</p>
        <div class="meta"><span>${post.authorName}</span><span>${new Date(post.createdAt).toLocaleDateString('vi-VN')}</span></div>
        <div class="post-actions">
          <button type="button" class="action-btn" data-action="like">❤ 0</button>
          <button type="button" class="action-btn" data-action="comment">💬 0</button>
          <button type="button" class="action-btn" data-action="save">🔖 Lưu</button>
        </div>
      </article>
    `).join('');
  }

  function renderBuiltInArticle(article) {
    const articlePage = document.querySelector('.article-page');
    if (!articlePage || !article) return;

    articlePage.dataset.postId = article.id;

    const categoryEl = articlePage.querySelector('[data-article-category]');
    const titleEl = articlePage.querySelector('[data-article-title]');
    const authorEl = articlePage.querySelector('[data-article-author]');
    const dateEl = articlePage.querySelector('[data-article-date]');
    const readTimeEl = articlePage.querySelector('[data-article-read-time]');
    const bannerEl = articlePage.querySelector('[data-article-banner]');
    const contentEl = articlePage.querySelector('[data-article-content]');
    const relatedEl = articlePage.querySelector('[data-article-related]');

    if (categoryEl) categoryEl.textContent = article.category;
    if (titleEl) titleEl.textContent = article.title;
    if (authorEl) authorEl.textContent = `Tác giả: ${article.author}`;
    if (dateEl) dateEl.textContent = `Đăng ngày: ${article.date}`;
    if (readTimeEl) readTimeEl.textContent = `Thời gian đọc: ${article.readTime}`;
    if (bannerEl) bannerEl.textContent = article.bannerText;

    if (contentEl) {
      const paragraphsHtml = article.paragraphs
        .map((paragraph) => `<p>${paragraph}</p>`)
        .join('');
      const bulletsHtml = Array.isArray(article.bullets) && article.bullets.length
        ? `
          <h2>${article.sectionTitle || 'Điểm nổi bật'}</h2>
          <ul>${article.bullets.map((bullet) => `<li>${bullet}</li>`).join('')}</ul>
        `
        : '';
      contentEl.innerHTML = `${paragraphsHtml}${bulletsHtml}`;
    }

    if (relatedEl && Array.isArray(article.related)) {
      relatedEl.innerHTML = article.related
        .map((relatedId) => articleById[relatedId])
        .filter(Boolean)
        .slice(0, 3)
        .map((relatedArticle) => `
          <article class="card related-item">
            <p class="chip">${relatedArticle.category}</p>
            <h3><a href="article-template.html?id=${encodeURIComponent(relatedArticle.id)}">${relatedArticle.title}</a></h3>
          </article>
        `)
        .join('');
    }
  }

  function hydrateArticleFromQuery() {
    const articlePage = document.querySelector('.article-page');
    if (!articlePage) return;

    const params = new URLSearchParams(window.location.search);
    const articleId = params.get('id');

    if (articleId && articleById[articleId]) {
      renderBuiltInArticle(articleById[articleId]);
      return;
    }

    const postId = params.get('postId');
    if (!postId || !store) return;
    const post = store.getPostById(postId);
    if (!post) return;

    articlePage.dataset.postId = post.id;
    const chip = articlePage.querySelector('[data-article-category]');
    const title = articlePage.querySelector('[data-article-title]');
    const author = articlePage.querySelector('[data-article-author]');
    const date = articlePage.querySelector('[data-article-date]');
    const readTime = articlePage.querySelector('[data-article-read-time]');
    const banner = articlePage.querySelector('[data-article-banner]');
    const content = articlePage.querySelector('[data-article-content]');

    if (chip) chip.textContent = post.category;
    if (title) title.textContent = post.title;
    if (author) author.textContent = `Tác giả: ${post.authorName}`;
    if (date) date.textContent = `Đăng ngày: ${new Date(post.createdAt).toLocaleDateString('vi-VN')}`;
    if (readTime) readTime.textContent = 'Thời gian đọc: 3 phút';
    if (banner) {
      banner.innerHTML = post.coverImage
        ? `<img src="${post.coverImage}" alt="Ảnh bìa bài viết" class="article-cover" />`
        : '🛰️ Ảnh đầu bài: Mô phỏng giao diện dự án số học sinh';
    }
    if (content) {
      content.innerHTML = `<p>${post.content}</p>`;
    }
  }

  function getBaseCount(button) {
    const match = button.textContent.match(/\d+/);
    return match ? Number(match[0]) : 0;
  }

  function setButtonCount(button, icon, count) {
    button.textContent = `${icon} ${count}`;
  }

  function renderCommentList(listEl, postId) {
    const comments = store ? store.getComments(postId) : [];
    if (!comments.length) {
      listEl.innerHTML = '<p class="comment-empty">Chưa có bình luận nào. Hãy là người đầu tiên chia sẻ nhé!</p>';
      return;
    }

    listEl.innerHTML = comments.map((comment) => `
      <article class="comment-item">
        <div class="comment-item-head">
          <strong>${comment.authorName}</strong>
          <span>${formatDate(comment.createdAt)}</span>
        </div>
        <p>${comment.content}</p>
      </article>
    `).join('');
  }

  function ensureCommentBox(container, postId) {
    const existing = container.parentElement.querySelector(`.comment-box[data-post-id="${postId}"]`);
    if (existing) return existing;

    const box = document.createElement('section');
    box.className = 'comment-box card';
    box.dataset.postId = postId;
    box.innerHTML = `
      <h4>Bình luận</h4>
      <textarea rows="3" placeholder="Chia sẻ ý kiến của bạn..."></textarea>
      <div class="comment-actions-row">
        <button type="button" class="btn btn-primary submit-btn">Gửi bình luận</button>
      </div>
      <div class="comment-list"></div>
    `;

    container.insertAdjacentElement('afterend', box);
    const listEl = box.querySelector('.comment-list');
    renderCommentList(listEl, postId);

    const submitBtn = box.querySelector('.submit-btn');
    const textarea = box.querySelector('textarea');
    submitBtn.addEventListener('click', () => {
      const content = textarea.value.trim();
      if (!content || !store) {
        textarea.focus();
        return;
      }
      store.addComment(postId, content, 'Bạn đọc học đường');
      textarea.value = '';
      renderCommentList(listEl, postId);

      const commentBtn = container.querySelector('[data-action="comment"]');
      if (commentBtn) {
        const count = store.getComments(postId).length;
        setButtonCount(commentBtn, '💬', count);
      }
    });

    return box;
  }

  function initReactions() {
    const postContainers = document.querySelectorAll('[data-post-id]');

    postContainers.forEach((container) => {
      const postId = container.dataset.postId;
      const likeBtn = container.querySelector('[data-action="like"]');
      const saveBtn = container.querySelector('[data-action="save"]');
      const commentBtn = container.querySelector('[data-action="comment"]');

      const reactionState = store ? store.getReaction(postId) : { liked: false, saved: false };

      if (likeBtn) {
        const base = getBaseCount(likeBtn);
        const displayCount = base + (reactionState.liked ? 1 : 0);
        likeBtn.dataset.baseCount = String(base);
        likeBtn.classList.toggle('active', Boolean(reactionState.liked));
        setButtonCount(likeBtn, '❤', displayCount);

        likeBtn.addEventListener('click', () => {
          if (!store) return;
          const current = store.getReaction(postId);
          const liked = !current.liked;
          store.setReaction(postId, { liked });
          likeBtn.classList.toggle('active', liked);
          const nextCount = Number(likeBtn.dataset.baseCount || 0) + (liked ? 1 : 0);
          setButtonCount(likeBtn, '❤', nextCount);
        });
      }

      if (saveBtn) {
        saveBtn.classList.toggle('active', Boolean(reactionState.saved));
        saveBtn.addEventListener('click', () => {
          if (!store) return;
          const current = store.getReaction(postId);
          const saved = !current.saved;
          store.setReaction(postId, { saved });
          saveBtn.classList.toggle('active', saved);
        });
      }

      if (commentBtn) {
        const comments = store ? store.getComments(postId) : [];
        setButtonCount(commentBtn, '💬', comments.length || getBaseCount(commentBtn));

        commentBtn.addEventListener('click', () => {
          const commentBox = ensureCommentBox(container.querySelector('.post-actions, .article-actions') || container, postId);
          commentBox.classList.toggle('open');
          if (commentBox.classList.contains('open')) {
            commentBox.querySelector('textarea').focus();
          }
        });
      }
    });
  }

  hydrateArticleFromQuery();
  renderCommunityPosts();
  initReactions();
})();
