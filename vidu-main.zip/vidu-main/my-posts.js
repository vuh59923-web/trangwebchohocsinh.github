(function () {
  const store = window.HocDuongStore;
  const root = document.getElementById('my-posts-list');
  if (!root || !store) return;

  const statusMap = {
    draft: 'Nháp',
    pending: 'Chờ duyệt',
    needs_revision: 'Cần chỉnh sửa',
    published: 'Đã xuất bản',
    rejected: 'Từ chối'
  };

  function render() {
    const posts = store.getPosts();

    if (!posts.length) {
      root.innerHTML = `
        <div class="empty-state card">
          <h3>Bạn chưa có bài viết nào</h3>
          <p>Nhấn “+ Đăng bài” để bắt đầu chia sẻ ý tưởng số đầu tiên của bạn.</p>
          <a class="btn btn-primary" href="submit-article.html">+ Đăng bài ngay</a>
        </div>
      `;
      return;
    }

    root.innerHTML = posts.map((post) => `
      <article class="card post-manage-item" data-id="${post.id}">
        <div class="post-manage-head">
          <h3>${post.title}</h3>
          <span class="status-badge status-${post.status}">${statusMap[post.status] || post.status}</span>
        </div>
        <p class="meta"><span>${post.category}</span><span>${new Date(post.createdAt).toLocaleDateString('vi-VN')}</span></p>
        <p>${post.excerpt}</p>
        ${post.reviewerNote ? `<p class="reviewer-note">Ghi chú admin: ${post.reviewerNote}</p>` : ''}
        <div class="post-actions">
          ${['draft', 'needs_revision'].includes(post.status) ? `<a class="action-btn" href="submit-article.html?editId=${post.id}">✏️ Sửa bài</a>` : ''}
          <a class="action-btn" href="article-template.html?postId=${post.id}">👁 Xem bài</a>
          ${post.status === 'needs_revision' ? `<button type="button" class="action-btn" data-resubmit="${post.id}">📨 Gửi lại phê duyệt</button>` : ''}
        </div>
      </article>
    `).join('');

    root.querySelectorAll('[data-resubmit]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const postId = btn.dataset.resubmit;
        store.updatePost(postId, { status: 'pending', reviewerNote: '' });
        render();
      });
    });
  }

  render();
})();
