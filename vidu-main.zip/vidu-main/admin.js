(function () {
  const store = window.HocDuongStore;
  const listEl = document.getElementById('admin-list');
  const detailEl = document.getElementById('admin-detail');
  const filterWrap = document.getElementById('admin-filters');
  if (!store || !listEl || !detailEl || !filterWrap) return;

  let currentFilter = 'pending';
  let selectedPostId = '';

  const statusMap = {
    draft: 'Bản nháp',
    pending: 'Chờ duyệt',
    needs_revision: 'Cần chỉnh sửa',
    published: 'Đã xuất bản',
    rejected: 'Từ chối'
  };

  function statusBadge(status) {
    return `<span class="status-badge status-${status}">${statusMap[status] || status}</span>`;
  }

  function renderList() {
    const posts = store.getPostsByStatus(currentFilter);
    if (!posts.length) {
      listEl.innerHTML = '<p class="empty-state">Không có bài nào ở trạng thái này.</p>';
      detailEl.innerHTML = '<p class="empty-state">Chọn trạng thái khác để xem dữ liệu.</p>';
      return;
    }

    listEl.innerHTML = posts.map((post) => `
      <article class="card admin-item ${selectedPostId === post.id ? 'active' : ''}" data-post-id="${post.id}">
        <h3>${post.title}</h3>
        <p class="meta"><span>${post.authorName}</span><span>${post.category}</span></p>
        <p class="meta"><span>${new Date(post.updatedAt).toLocaleDateString('vi-VN')}</span>${statusBadge(post.status)}</p>
        <button class="action-btn" type="button" data-view="${post.id}">Xem chi tiết</button>
      </article>
    `).join('');

    listEl.querySelectorAll('[data-view]').forEach((button) => {
      button.addEventListener('click', () => {
        selectedPostId = button.dataset.view;
        renderList();
        renderDetail(selectedPostId);
      });
    });

    const firstId = selectedPostId || posts[0].id;
    selectedPostId = firstId;
    renderDetail(firstId);
  }

  function updateStatus(postId, status, note) {
    store.updatePost(postId, {
      status,
      reviewerNote: note || '',
      reviewedAt: new Date().toISOString()
    });
    renderList();
  }

  function renderDetail(postId) {
    const post = store.getPostById(postId);
    if (!post) return;

    detailEl.innerHTML = `
      <h2>${post.title}</h2>
      <p class="meta"><span>${post.authorName} · ${post.authorRole || 'Cộng tác viên'}</span><span>${post.category}</span></p>
      ${statusBadge(post.status)}
      <p><strong>Mô tả:</strong> ${post.excerpt}</p>
      <p><strong>Tag:</strong> ${post.tags || 'Chưa có tag'}</p>
      ${post.coverImage ? `<img class="admin-cover" src="${post.coverImage}" alt="Ảnh bìa bài viết" />` : ''}
      <article class="admin-article-content">${post.content}</article>
      <label class="form-group" for="admin-note">
        <span>Ghi chú phản hồi (bắt buộc khi yêu cầu sửa / từ chối)</span>
        <textarea id="admin-note" rows="3" placeholder="Nhập góp ý cụ thể cho tác giả...">${post.reviewerNote || ''}</textarea>
      </label>
      <div class="post-actions">
        <button type="button" class="btn btn-primary" data-approve="${post.id}">Duyệt & xuất bản</button>
        <button type="button" class="btn btn-outline" data-revise="${post.id}">Yêu cầu chỉnh sửa</button>
        <button type="button" class="btn btn-outline" data-reject="${post.id}">Từ chối</button>
      </div>
    `;

    const noteInput = detailEl.querySelector('#admin-note');

    detailEl.querySelector('[data-approve]').addEventListener('click', () => {
      updateStatus(post.id, 'published', noteInput.value.trim() || 'Bài viết đạt yêu cầu, đã được xuất bản.');
    });

    detailEl.querySelector('[data-revise]').addEventListener('click', () => {
      const note = noteInput.value.trim();
      if (!note) {
        noteInput.focus();
        return;
      }
      updateStatus(post.id, 'needs_revision', note);
    });

    detailEl.querySelector('[data-reject]').addEventListener('click', () => {
      const note = noteInput.value.trim();
      if (!note) {
        noteInput.focus();
        return;
      }
      updateStatus(post.id, 'rejected', note);
    });
  }

  filterWrap.querySelectorAll('[data-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      currentFilter = btn.dataset.filter;
      selectedPostId = '';
      filterWrap.querySelectorAll('[data-filter]').forEach((item) => item.classList.remove('active'));
      btn.classList.add('active');
      renderList();
    });
  });

  renderList();
})();
